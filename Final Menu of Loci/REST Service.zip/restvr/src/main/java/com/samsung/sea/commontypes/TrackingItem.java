package com.samsung.sea.commontypes;

/**
 * Meant to aid in the use of generics with other classes in
 * the sea.commontypes package. Contains no methods of its own and is
 * abstract.
 * @author sean.dyer
 *
 */
public abstract class TrackingItem {

}

