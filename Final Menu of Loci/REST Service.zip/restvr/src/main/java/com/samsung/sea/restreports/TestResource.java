package com.samsung.sea.restreports;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.samsung.sea.commontypes.MovieDetail;
import com.samsung.sea.commontypes.MovieDetail;

@Path("Test")
public class TestResource {
	  @GET
	  @Produces(MediaType.APPLICATION_JSON)
	  public final String getAll()
	      throws Exception {
	    
	    List<MovieDetail> MovieDetailList = new ArrayList<MovieDetail>();    
	    
	   MovieDetail nextMovieDetail = new MovieDetail(
	          1,
	          "Diving.jpg", "LMFAO.mp4",
	          "Music");
	   MovieDetailList.add(nextMovieDetail);
	  
	    
	    ObjectMapper objectMapper = new ObjectMapper();
	    objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
	    String MovieDetailListAsString = objectMapper.writeValueAsString(MovieDetailList);

	    return MovieDetailListAsString;
	  }

}
