package com.samsung.sea.restreports;


/**
 * Contains constants needed for connecting to the database.
 * If you need to change your database location, username,
 * or password, here is where you make that change.
 * 
 * This might be better replaced with a file containing the
 * database info, where the system is deployed.
 * @author sean.dyer
 *
 */
public final class DatabaseConstants {
  /**
   * The SQL driver.
   */
  public static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
  /**
   * The database location.
   */
  public static final String DB_URL = "jdbc:mysql://localhost:3306/";
  /**
   * The username for the database. For security, I suggest a username
   * be created other than 'root'.
   */
  public static final String USER = "root";
  /**
   * The password for the database. For security, I suggest a password
   * be created other than 'root'.
   */
  public static final String PASS = "root";

  /**
   * Constructor for the class. Made private to
   * prevent this class from being instantiated.
   */
  private DatabaseConstants() {
    //Here to prevent class from being instantiated.
  }
}
