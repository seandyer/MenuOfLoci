/**
 * This package collects the different Rest resources
 * for the reports system. Each resource provides get
 * and put methods for various items (in the com.samsung.sea.commontypes
 * package, which inherit from TrackingItem.
 */
package com.samsung.sea.restreports;
