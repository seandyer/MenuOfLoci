package com.samsung.sea.restreports;

import static com.samsung.sea.restreports.DatabaseConstants.DB_URL;
import static com.samsung.sea.restreports.DatabaseConstants.PASS;
import static com.samsung.sea.restreports.DatabaseConstants.USER;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.samsung.sea.commontypes.TrackingItem;
  

/**
 * Provides common methods for resources that should
 * be queried in the database. Contains an abstract
 * method, processResultSet, which must be implemented
 * by inheriting classes.
 * @author sean.dyer
 *
 */
public abstract class QueryableResource {

  /**
   * Queries the database for a REST resource and returns a list
   * of whatever the user was trying to query for.
   * @param queryString
   * The query string
   * @return List<T>
   * An list of objects corresponding to whatever we were trying
   * to query from. You can find these classes in
   * com.samsung.sea.commontypes.
   * @throws Exception
   * For missing jdbc driver, bad connection, errors
   * when closing the connection.
   */
  public final List<? extends TrackingItem> getQuery(final String queryString,
      List<String> queryParamStrings)
      throws Exception {
    /**
     * Loads the SQL driver.
     */
    try {
      Class.forName("com.mysql.jdbc.Driver");
    } catch (ClassNotFoundException e) {
      System.out.println("Where is your MySQL JDBC Driver?");
      e.printStackTrace();
    }
    /**
     * Will be initialized with connection details: database, username,
     * password.
     */
    Connection connection = null;
    /**
     * Will hold the query statement.
     */
    Statement statement = null;

    try {
      /**
       * Connects and creates the statement.
       */
      connection = DriverManager.getConnection(DB_URL + "vrservice",
          USER, PASS);
      if (connection == null) {
        throw new SQLException("Failed to connect!");
        
      }
      statement = connection.createStatement();
      if (statement == null) {
        throw new Exception("This statement is null!");
      
      }
      
      PreparedStatement ps = connection.prepareStatement(queryString);
      System.out.println(ps.toString());
      /**
       * Adds in the query params (if any exist).
       */
      if (queryParamStrings.size() > 0) {
        int i = 0;
        for (String paramString: queryParamStrings) {
          i++;
          ps.setString(i, paramString);
        }
      }
      System.out.println(ps.toString());
      System.out.println(ps.toString());
//      if(true) {
//        throw new Exception(ps.toString());
//      }
      /**
       * Executes the query and processes the result set.
       * For now, this just returns the first name in the set.
       */
      ResultSet resultSet = ps.executeQuery();      
      ResultSetMetaData rsmd = resultSet.getMetaData();   
      System.out.println(rsmd.getColumnCount());
//      if (resultSet == null) {
//
//        String id = "";
//
//        throw new Exception("It's null!" + rsmd.getColumnCount() + " " + rsmd.getColumnLabel(1) + id);
//
//      }

      return processResultSet(resultSet);
    } catch (SQLException e) {
      return null;
    } finally {
        // Close the connection and release the resources used.
      try {
    	if (statement != null) {
    		statement.close();	
    	}
        
      } catch (SQLException e) {
        e.printStackTrace();
      }

      try {
    	if (connection != null) {
    		connection.close();
    	}
        
      } catch (SQLException e) {
        e.printStackTrace();
      }

    }
    /**
     * Should not get reached, but here just in case.
     */
    
  }
  
  
  public final List<? extends TrackingItem> query(final String queryString)
      throws Exception {
    return getQuery(queryString, new ArrayList<String>());
  }

  /**
   * Processes the result set for the specific subclass of
   * QueryableResource.
   * @param rs
   * The result from the SQL query just prior to this call.
   * @return List<T>
   * The list of objects that the subclass is looking up.
   * @throws SQLException
   * General catch-all for any SQL issues when iterating through
   * the result set.
   * @throws Exception 
   *
   */
  public abstract List<? extends TrackingItem> processResultSet(ResultSet rs)
      throws SQLException, Exception;
  
  public final ResultSet putQuery(final String queryString,
      List<String> queryParamStrings)
      throws Exception {
    /**
     * Loads the SQL driver.
     */
    try {
      Class.forName("com.mysql.jdbc.Driver");
    } catch (ClassNotFoundException e) {
      System.out.println("Where is your MySQL JDBC Driver?");
      e.printStackTrace();
    }
    /**
     * Will be initialized with connection details: database, username,
     * password.
     */
    Connection connection = null;
    /**
     * Will hold the query statement.
     */
    Statement statement = null;

    try {
      /**
       * Connects and creates the statement.
       */
      connection = DriverManager.getConnection(DB_URL + "weeklyreports",
          USER, PASS);
      if (connection == null) {
        throw new SQLException("Failed to connect!");
        
      }
      connection.setAutoCommit(true);
      
      PreparedStatement ps = connection.prepareStatement(queryString, Statement.RETURN_GENERATED_KEYS);
      /**
       * Adds in the query params (if any exist).
       */
      if (queryParamStrings.size() > 0) {
        int i = 0;
        for (String paramString: queryParamStrings) {
          i++;
          ps.setString(i, paramString);
          //System.out.println(ps.toString());
        }
      } else {
        throw new Exception(queryParamStrings.toString());
      }

       /**
       * Executes the query and processes the result set.
       * For now, this just returns the first name in the set.
       */
      System.out.println(queryString.toString());
      System.out.println(ps.toString());
      ps.executeUpdate();
      ResultSet rs = ps.getGeneratedKeys();
      return rs;
      
  }finally {
    // Close the connection and release the resources used.
/*  try {
    statement.close();
  } catch (SQLException e) {
    e.printStackTrace();
  }*/

//  try {
//    connection.close();
//  } catch (SQLException e) {
//    e.printStackTrace();
//  }

  }

  }
}
