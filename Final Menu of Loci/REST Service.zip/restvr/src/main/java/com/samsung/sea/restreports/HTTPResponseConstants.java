package com.samsung.sea.restreports;

/**
 * Contains constants for HTTP responses. Java provides a class,
 * but this lets us see which ones are actually in use by the service.
 * @author sean.dyer
 *
 */
public final class HTTPResponseConstants {
  /**
   * Used for successful HTTP responses.
   */
  public static final int STATUS_OK = 200;
  /**
   * Used when no content was provided for the 
   * service to work with.
   */
  public static final int STATUS_NO_CONTENT = 204;
  
  /**
   * Constructor for the class. Made private to
   * prevent this class from being instantiated.
   */
  private HTTPResponseConstants() {
    //Here to prevent class from being instantiated.
  }
}
