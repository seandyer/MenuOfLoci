package com.samsung.sea.restreports;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.samsung.sea.commontypes.MovieDetail;
import com.samsung.sea.commontypes.TrackingItem;

@Path("movies")
public class MovieResource extends QueryableResource {
	private String results;
	/**
	   * Method handling HTTP GET requests when no further
	   * items are (/pto, not /pto/whatever). A query is
	   * sent to the SQL server.
	   * The returned object will be sent
	   * to the client as JSON.
	   *
	   * @return String that will be returned as a text/plain response.
	   * @throws Exception if the query goes wrong.
	   */
	  @GET
	  @Produces(MediaType.APPLICATION_JSON)
	  public final String getAll()
	      throws Exception {
	    
	    List<MovieDetail> MovieDetailList = new ArrayList<MovieDetail>();    
	    String queryString = "SELECT * FROM video";
	    List<? extends TrackingItem> queryResult = query(queryString);
	    if (queryResult == null/* || queryResult.size() <= 0 */) {
	      throw new Exception("There's nothing there!");
	    }
	    MovieDetailList.addAll((List<MovieDetail>) queryResult);
	    ObjectMapper objectMapper = new ObjectMapper();
	    objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
	    String MovieDetailListAsString = objectMapper.writeValueAsString(MovieDetailList);
	    /*String queryString = "SELECT * FROM MovieDetail";
	    return query(queryString);*/
	    //return ptoList;
	    return MovieDetailListAsString;
	  }

	  @GET
	  @Path ("{category}")
	  @Produces(MediaType.APPLICATION_JSON)
	  public final String getCategories(@PathParam("category") String category)	              
	      throws Exception {
	    List<MovieDetail> ptoList = new ArrayList<MovieDetail>();
	    String queryString = "SELECT * FROM video WHERE category=?";        

	    List<String> paramStrings = new ArrayList<String>();   
	    
	    paramStrings.add(category);
	    List<? extends TrackingItem> queryResult = getQuery(queryString, paramStrings);
	    if (queryResult == null/* || queryResult.size() <= 0 */) {
	      throw new Exception("There's nothing there!");
	    }
	    ptoList.addAll((List<MovieDetail>) queryResult);
	    ObjectMapper objectMapper = new ObjectMapper();
	    objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
	    String ptoListAsString = objectMapper.writeValueAsString(ptoList);
	    

	    return ptoListAsString;
	  }
	  
		  /**
	   * Takes a result set from one of the queries, using it to
	   * build a list of MovieDetail items, which is then passed back to the
	   * original get method via the query class.
	   * @param rs
	   * the result set from an SQL query.
	   * @return List<? extends TrackingItem>
	   * The list of items created from the SQL entries.
		 * @throws Exception 
	   */
	  public final List<? extends TrackingItem> processResultSet(
	      final ResultSet rs)
	      throws Exception {
		  results = rs.toString();
	    List<MovieDetail> allMovieDetails = new ArrayList<MovieDetail>();
	
	    while (rs.next()) {
	      MovieDetail nextMovieDetail = new MovieDetail(
	          rs.getInt("videonum"),
	          rs.getString("thumbnail"), rs.getString("video"),
	          rs.getString("category"));
	      allMovieDetails.add(nextMovieDetail);
	    }
	    return allMovieDetails;
	  }

}
