/**
 * Contains classes that are common to multiple parts
 * of the system, such as PTO or Employees.
 */
package com.samsung.sea.commontypes;
