package com.samsung.sea.commontypes;

public class MovieDetail extends TrackingItem {
	
	private int videonum;

	private String thumbnail;
	
	private String video;
	
	private String category;

	public MovieDetail(int videonum, String thumbnail, String video,
			String category) {
		super();
		this.videonum = videonum;
		this.thumbnail = thumbnail;
		this.video = video;
		this.category = category;
	}

	public int getVideonum() {
		return videonum;
	}

	public void setVideonum(int videonum) {
		this.videonum = videonum;
	}

	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public String getVideo() {
		return video;
	}

	public void setVideo(String video) {
		this.video = video;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	
	
	
}
