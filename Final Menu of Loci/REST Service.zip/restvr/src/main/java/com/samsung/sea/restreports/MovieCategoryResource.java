package com.samsung.sea.restreports;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.samsung.sea.commontypes.MovieCategory;
import com.samsung.sea.commontypes.TrackingItem;

@Path("categories")
public class MovieCategoryResource extends QueryableResource {

	/**
	   * Method handling HTTP GET requests when no further
	   * items are (/pto, not /pto/whatever). A query is
	   * sent to the SQL server.
	   * The returned object will be sent
	   * to the client as JSON.
	   *
	   * @return String that will be returned as a text/plain response.
	   * @throws Exception if the query goes wrong.
	   */
	  @GET
	  @Produces(MediaType.APPLICATION_JSON)
	  public final String getAll()
	      throws Exception {
	    
	    List<MovieCategory> MovieCategoryList = new ArrayList<MovieCategory>();    
	    String queryString = "SELECT DISTINCT category FROM video";
	    List<? extends TrackingItem> queryResult = query(queryString);
	    if (queryResult == null/* || queryResult.size() <= 0 */) {
	      throw new Exception("There's nothing there!");
	    }
	    MovieCategoryList.addAll((List<MovieCategory>) queryResult);
	    ObjectMapper objectMapper = new ObjectMapper();
	    objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
	    String MovieCategoryListAsString = objectMapper.writeValueAsString(MovieCategoryList);
	    /*String queryString = "SELECT * FROM MovieCategory";
	    return query(queryString);*/
	    //return ptoList;
	    return MovieCategoryListAsString;
	  }

	  
		  /**
	   * Takes a result set from one of the queries, using it to
	   * build a list of MovieCategory items, which is then passed back to the
	   * original get method via the query class.
	   * @param rs
	   * the result set from an SQL query.
	   * @return List<? extends TrackingItem>
	   * The list of items created from the SQL entries.
		 * @throws Exception 
	   */
	  public final List<? extends TrackingItem> processResultSet(
	      final ResultSet rs)
	      throws Exception {
		  
	    List<MovieCategory> allMovieCategorys = new ArrayList<MovieCategory>();
	
	    while (rs.next()) {
	      MovieCategory nextMovieCategory = new MovieCategory(
	          rs.getString("category"));
	      allMovieCategorys.add(nextMovieCategory);
	    }
	    return allMovieCategorys;
	  }

}
